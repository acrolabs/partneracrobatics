<!-- start Simple Custom CSS and JS -->
<script type="text/javascript">
/* Add your JavaScript code here.
                     
If you are using the jQuery library, then don't forget to wrap your code inside jQuery.ready() as follows:

jQuery(document).ready(function( $ ){
    // Your code in here 
});

End of comment */ 
jQuery(window).load(function(){
  jQuery(".oneall_social_login,.oneall_social_link").wrap("<div style='height: 30px; overflow:hidden'></div>");
});

</script>
<!-- end Simple Custom CSS and JS -->
